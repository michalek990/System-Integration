# -*- coding: utf-8 -*-
"""
json to yaml converter
"""
import json
import yaml
class ConvertJsonToYaml:


    @staticmethod
    def run(deserializeddata, destinationfilelocaiton):
        print("ConvertJsonToYaml")
        with open(destinationfilelocaiton, 'w', encoding='utf-8') as f: yaml.dump(deserializeddata, f, allow_unicode=True)
        print("it is done")

    @staticmethod
    def run_2(sourcejsonfilelocation, destinationfilelocaiton):
        print("ConvertJsonToYaml")
        temp = open(sourcejsonfilelocation, encoding="utf8")
        data = json.load(temp)
        with open(destinationfilelocaiton, 'w', encoding='utf-8') as f: yaml.dump(data, f, allow_unicode=True)
        print("it is done")