# -*- coding: utf-8 -*-
"""
deserialize json
"""
import json
class DeserializeJson:
 # konstruktor
     def __init__(self, filename):
         print("DeserializeJson")
         tempdata = open(filename, encoding="utf8")
         self.data = json.load(tempdata)
     # przykładowe statystyki
     def somestats(self):

        map ={}
        example_stat = 0
        for dep in self.data:
            if dep['typ_JST'] == 'GM' and dep['Województwo'] == 'dolnośląskie':
                example_stat += 1

            temp = (dep['Województwo']).strip()
            if (temp) in map and dep["nazwa_urzędu_JST"] != "":
              map[temp] += 1
            else :
              map[temp] = 1

        for i in map:
            print('liczba urzędów miejskich w województwie ' + str(i) + ' ' + str(map[i]))
