﻿using System.Xml;
using System.Xml.XPath;



string xmlpath = Path.Combine("Assets", "data.xml");
    Console.WriteLine("###########################################");   
    Console.WriteLine("XML loaded by DOM Approach");
    XMLReadWithDOMApproach.Read(xmlpath);
    Console.WriteLine("###########################################");
    Console.WriteLine("XML loaded by SAX Approach");
    XMLReadWithSAXApproach.Read(xmlpath);
    Console.WriteLine("###########################################");
    Console.WriteLine("XML loaded by XPath");
    XMLReadWithXLSTDOM.Read(xmlpath);
    Console.WriteLine("###########################################");
    Console.ReadLine();





class XMLReadWithDOMApproach
{
    internal static void Read(string filepath)
    {

        // odczyt zawartości dokumentu
        XmlDocument doc = new XmlDocument();
        doc.Load(filepath);
        string postac;
        string sc;
        int count = 0;
        var drugs = doc.GetElementsByTagName("produktLeczniczy");
        
        var leki = new Dictionary<string, HashSet<string>>();

        var Substanile = new Dictionary<string, int>();

        foreach (XmlNode d in drugs)
        {
            postac = d.Attributes.GetNamedItem("postac").Value;
            sc = d.Attributes.GetNamedItem("nazwaPowszechnieStosowana").Value;
           
            if (postac == "Krem" && sc == "Mometasoni furoas") count++;
            if (leki.ContainsKey(sc))
            {
                HashSet<string> set = leki[sc];
              
                set.Add(postac);
                leki[sc] = set;
            }
            else
            {
                HashSet<string> set = new HashSet<string>();
                
                set.Add(postac);
                leki[sc] = set;

            }

            var substancjeCzynneNode = d.ChildNodes[0];
            for (int i = 0; i < substancjeCzynneNode.ChildNodes.Count; i++)
            {
                string Substant = substancjeCzynneNode.ChildNodes[i].InnerText;
                if (!Substanile.ContainsKey(Substant))
                {
                    Substanile[Substant] = 0;
                }
                Substanile[Substant]++;
            }

        }

        int Postacie = 0;
      
        foreach (KeyValuePair<string, HashSet<string>> entry in leki)
        { 
            if(entry.Value.Count > 1)
            {
                Postacie++;
            }
        }
       string maxSc = Substanile.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;

        Console.WriteLine("Liczba produktów leczniczych w postaci kremu, których jedyną substancją czynną jest Mometasoni furoas {0}", count);
        Console.WriteLine("Substancja czynna występująca w największej liczbie produktów leczniczych: {0}", maxSc);
        Console.WriteLine("1.2.4) Leki pod różnymi postaciami {0}", Postacie);
    }
}















class XMLReadWithSAXApproach
{
    internal static void Read(string filepath)
    {
        XmlReaderSettings settings = new XmlReaderSettings();
        settings.IgnoreComments = true;
        settings.IgnoreProcessingInstructions = true;
        settings.IgnoreWhitespace = true;
        // odczyt zawartości dokumentu
        XmlReader reader = XmlReader.Create(filepath, settings);
        // zmienne pomocnicze
        int count = 0;
        string postac = "";
        string sc = "";
        reader.MoveToContent();
        var leki = new Dictionary<string, HashSet<string>>();
        var substantIle = new Dictionary<string, int>();
        while (reader.Read())
        {
            if (reader.NodeType == XmlNodeType.Element && reader.Name == "produktLeczniczy")
            {
                postac = reader.GetAttribute("postac");
                sc = reader.GetAttribute("nazwaPowszechnieStosowana");
                if (postac == "Krem" && sc == "Mometasoni furoas")
                    count++;
            }
            if (leki.ContainsKey(sc))
            {
                HashSet<string> set = leki[sc];
                set.Add(postac);
                leki[sc] = set;
            }
            else
            {
                HashSet<string> set = new HashSet<string>();
                set.Add(postac);
                leki[sc] = set;

            }
            if (reader.NodeType == XmlNodeType.Element && reader.Name == "substancjaCzynna")
            {
                reader.Read();
                var substnat = reader.Value;
                if (!substantIle.ContainsKey(substnat))
                {
                    substantIle[substnat] = 0;
                }
                substantIle[substnat]++;
            }
        }
        int Postacie = 0;

        foreach (KeyValuePair<string, HashSet<string>> entry in leki)
        {
            if (entry.Value.Count > 1)
            {
                Postacie++;
            }
        }
        string max = substantIle.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;

        Console.WriteLine("Liczba produktów leczniczych w postaci kremu, których jedyną substancją czynną jest Mometasoni furoas {0}", count);
        Console.WriteLine("Substancja czynna występująca w największej liczbie produktów leczniczych: {0}", max);
        Console.WriteLine("1.3.4) Leki pod różnymi postaciami {0}", Postacie);

    }
}
















internal class XMLReadWithXLSTDOM
{
    internal static void Read(string xmlpath)
    {
       

        XPathDocument document = new XPathDocument(xmlpath);
        XPathNavigator navigator = document.CreateNavigator();

        XmlNamespaceManager manager = new XmlNamespaceManager(navigator.NameTable);
        manager.AddNamespace("x", "http://rejestrymedyczne.ezdrowie.gov.pl/rpl/eksport-danych-v1.0");

        XPathExpression query = navigator.Compile("/x:produktyLecznicze/x:produktLeczniczy[@postac='Krem' and @nazwaPowszechnieStosowana='Mometasoni furoas']");
        query.SetContext(manager);
        int count = navigator.Select(query).Count;
        
       
        query = navigator.Compile("/x:produktyLecznicze/x:produktLeczniczy");
        query.SetContext(manager);
        var XPathNavigator = navigator.Select(query);
        

        var substantIle = new Dictionary<string, int>();
        var leki = new Dictionary<string, HashSet<string>>();



        while (XPathNavigator.MoveNext())
        {
            XPathNavigator node = XPathNavigator.Current;
            
                string postac = ("/x:produktyLecznicze/x:produktLeczniczy[@postac='Krem']");
                string sc = ("/x:produktyLecznicze/x:produktLeczniczy[@nazwaPowszechnieStosowana = 'Mometasoni furoas']");
                if (postac == "Krem" && sc == "Mometasoni furoas") { count++; }
           

            node = XPathNavigator.Current;
            query = node.Compile("./x:substancjeCzynne/x:substancjaCzynna");
            query.SetContext(manager);

            
            var iter2 = node.Select(query);


            if (leki.ContainsKey(sc))
            {
                HashSet<string> set = leki[sc];
                set.Add(postac);
                leki[sc] = set;
            }
            else
            {
                HashSet<string> set = new HashSet<string>();
                set.Add(postac);
                leki[sc] = set;

            }

            while (iter2.MoveNext())
            {
                
              
                node = iter2.Current;
                string substant = node.Value;
                if (!substantIle.ContainsKey(substant))
                {
                    substantIle[substant] = 0;
                }
                substantIle[substant]++;
            }
        }




        int Postacie = 0;

        foreach (KeyValuePair<string, HashSet<string>> entry in leki)
        {
            if (entry.Value.Count > 1)
            {
                Postacie++;
            }
        }




        string max = substantIle.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;

        Console.WriteLine("Liczba produktów leczniczych w postaci kremu, których jedyną substancją czynną jest Mometasoni furoas {0}", count);
        Console.WriteLine("Substancja czynna występująca w największej liczbie produktów leczniczych: {0}", max);
        Console.WriteLine("1.4.4) Leki pod różnymi postaciami {0}", Postacie);
    }
}
